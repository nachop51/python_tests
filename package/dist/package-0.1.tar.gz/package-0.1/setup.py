from setuptools import setup

setup(
    name="package",
    version="0.1",
    description="example package",
    author="nacho",
    author_email="nachoperalta0@gmail.com",
    url="https://github.com/Nachop51/",
    scripts=[],
    packages=["."]
)

